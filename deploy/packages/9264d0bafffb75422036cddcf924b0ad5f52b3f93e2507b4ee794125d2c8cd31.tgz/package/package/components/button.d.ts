import type { JSX } from 'solid-js';
export interface ButtonProps extends JSX.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger';
  size?: 'small' | 'medium' | 'large';
  loading?: boolean;
}
export declare function Button(props: ButtonProps): JSX.Element;
export declare const modelDigest: "fb89a6c7da3d24b06ce460e02d60941a1dc33621cc70df51098d707e9255e776";
export default Button;
