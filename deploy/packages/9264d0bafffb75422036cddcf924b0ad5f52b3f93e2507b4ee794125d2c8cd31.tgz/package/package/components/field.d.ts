import type { JSX } from 'solid-js';
export interface FieldProps extends Omit<JSX.InputHTMLAttributes<HTMLInputElement>, 'id' | 'value' | 'disabled' | 'required' | 'class' | 'children'> {
  id: string;
  label: JSX.Element;
  description?: JSX.Element;
  error?: JSX.Element;
  required?: boolean;
  disabled?: boolean;
  value?: string | number;
  class?: string;
  onInput?: JSX.EventHandler<HTMLInputElement, InputEvent>;
}
export declare const Field: ((props: FieldProps) => JSX.Element) & { NativeInput: typeof FieldNativeInput };
export declare const modelDigest: "6680d3b6e5ef5e85c4340fd8369a05f55c9a388c2bfb7ada7da9eeb0eccd29f3";
export interface CompoundPartProps extends import('solid-js').JSX.HTMLAttributes<HTMLDivElement> { children?: import('solid-js').JSX.Element; }
export declare const FieldNativeInput: (props: CompoundPartProps) => import('solid-js').JSX.Element;
export default Field;
